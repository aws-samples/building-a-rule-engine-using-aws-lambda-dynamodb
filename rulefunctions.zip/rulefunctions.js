module.exports = {
  func1: function () {
    // func1 impl
  },
  func2: function () {
    // func2 impl
  }
};